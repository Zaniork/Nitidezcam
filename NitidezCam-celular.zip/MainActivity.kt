package com.nitidez.cam

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.*
import android.hardware.camera2.CaptureRequest
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.renderscript.*
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

@androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
class MainActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView
    private lateinit var grid: View
    private lateinit var shutter: TextView
    private lateinit var expSeek: SeekBar
    private lateinit var countdown: TextView
    private var provider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var front = false
    private var videoMode = false
    private var flash = 0          // 0 off, 1 auto, 2 on, 3 lanterna
    private var timerSec = 0
    private var sharp = 4          // 0..10
    private var expMin = 0
    private val bg = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, onClick: (TextView) -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER
        setPadding(dp(12), dp(10), dp(12), dp(10)); setOnClickListener { onClick(this) }
    }

    private fun seek(max: Int, prog: Int, onC: (Int) -> Unit) = SeekBar(this).apply {
        this.max = max; progress = prog
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) onC(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun row(label: String, sb: SeekBar) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        addView(TextView(context).apply { text = label; setTextColor(Color.WHITE); textSize = 13f },
            LinearLayout.LayoutParams(dp(80), -2))
        addView(sb, LinearLayout.LayoutParams(0, -2, 1f))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        preview = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FIT_CENTER }
        root.addView(preview, -1, -1)

        grid = object : View(this) {
            val p = Paint().apply { color = 0x88FFFFFF.toInt(); strokeWidth = 2f }
            override fun onDraw(c: Canvas) {
                for (i in 1..2) {
                    c.drawLine(width * i / 3f, 0f, width * i / 3f, height.toFloat(), p)
                    c.drawLine(0f, height * i / 3f, width.toFloat(), height * i / 3f, p)
                }
            }
        }.apply { visibility = View.GONE }
        root.addView(grid, -1, -1)

        countdown = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 90f; gravity = Gravity.CENTER
        }
        root.addView(countdown, FrameLayout.LayoutParams(-1, -1))

        // Barra superior
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setBackgroundColor(0x66000000); setPadding(0, dp(30), 0, 0)
        }
        top.addView(tv("⚡ Off") { v ->
            flash = (flash + 1) % 4
            v.text = listOf("⚡ Off", "⚡ Auto", "⚡ On", "🔦 Lanterna")[flash]
            imageCapture?.flashMode = when (flash) {
                1 -> ImageCapture.FLASH_MODE_AUTO; 2 -> ImageCapture.FLASH_MODE_ON
                else -> ImageCapture.FLASH_MODE_OFF
            }
            camera?.cameraControl?.enableTorch(flash == 3)
        })
        top.addView(tv("⏱ 0s") { v ->
            timerSec = when (timerSec) { 0 -> 3; 3 -> 10; else -> 0 }; v.text = "⏱ ${timerSec}s"
        })
        top.addView(tv("▦ Grade") { grid.visibility = if (grid.visibility == View.GONE) View.VISIBLE else View.GONE })
        top.addView(tv("🔄 Virar") { front = !front; bind() })
        root.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        // Painel inferior
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0x88000000.toInt())
            setPadding(dp(12), dp(8), dp(12), dp(24))
        }
        bottom.addView(row("Zoom", seek(100, 0) { camera?.cameraControl?.setLinearZoom(it / 100f) }))
        expSeek = seek(1, 0) { camera?.cameraControl?.setExposureCompensationIndex(it + expMin) }
        bottom.addView(row("Exposição", expSeek))
        val sharpLabel = TextView(this)
        bottom.addView(row("Nitidez", seek(10, sharp) { sharp = it }))
        val ctrl = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val modeBtn = tv("📷 Foto") { v ->
            if (recording != null) return@tv
            videoMode = !videoMode; v.text = if (videoMode) "🎥 Vídeo" else "📷 Foto"
            shutter.text = if (videoMode) "⏺" else "⬤"; bind()
        }
        shutter = tv("⬤") { onShutter() }.apply { textSize = 48f }
        ctrl.addView(modeBtn, LinearLayout.LayoutParams(0, -2, 1f))
        ctrl.addView(shutter, LinearLayout.LayoutParams(0, -2, 1f))
        ctrl.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        bottom.addView(ctrl)
        root.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)

        // Toque para focar + pinça para zoom
        val tap = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                val pt = preview.meteringPointFactory.createPoint(e.x, e.y)
                camera?.cameraControl?.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
                return true
            }
        })
        val pinch = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val z = camera?.cameraInfo?.zoomState?.value?.zoomRatio ?: return true
                camera?.cameraControl?.setZoomRatio(z * d.scaleFactor); return true
            }
        })
        preview.setOnTouchListener { _, e -> pinch.onTouchEvent(e); tap.onTouchEvent(e); true }

        val need = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (need.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) start()
        else ActivityCompat.requestPermissions(this, need, 1)
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) start()
        else toast("Permissão da câmera necessária")
    }

    private fun start() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({ provider = f.get(); bind() }, ContextCompat.getMainExecutor(this))
    }

    // Força borda e redução de ruído em alta qualidade no hardware
    private fun <T> hq(b: ExtendableBuilder<T>) {
        Camera2Interop.Extender(b)
            .setCaptureRequestOption(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_HIGH_QUALITY)
            .setCaptureRequestOption(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY)
    }

    private fun bind() {
        val p = provider ?: return
        p.unbindAll()
        val sel = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
        val pv = Preview.Builder().also { hq(it) }.build().also { it.setSurfaceProvider(preview.surfaceProvider) }
        try {
            camera = if (videoMode) {
                val rec = Recorder.Builder().setQualitySelector(QualitySelector.from(
                    Quality.UHD, FallbackStrategy.lowerQualityOrHigherThan(Quality.UHD))).build()
                videoCapture = VideoCapture.withOutput(rec); imageCapture = null
                p.bindToLifecycle(this, sel, pv, videoCapture!!)
            } else {
                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setJpegQuality(100).also { hq(it) }.build()
                videoCapture = null
                p.bindToLifecycle(this, sel, pv, imageCapture!!)
            }
        } catch (e: Exception) { toast("Erro ao abrir câmera: ${e.message}"); return }
        val r = camera!!.cameraInfo.exposureState.exposureCompensationRange
        expMin = r.lower; expSeek.max = r.upper - r.lower; expSeek.progress = -r.lower
        camera!!.cameraControl.enableTorch(flash == 3)
    }

    private fun onShutter() {
        if (videoMode) { toggleVideo(); return }
        if (timerSec == 0) { takePhoto(); return }
        var left = timerSec
        val tick = object : Runnable {
            override fun run() {
                if (left > 0) { countdown.text = "$left"; left--; ui.postDelayed(this, 1000) }
                else { countdown.text = ""; takePhoto() }
            }
        }
        tick.run()
    }

    private fun takePhoto() {
        val ic = imageCapture ?: return
        ic.takePicture(bg, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val rot = image.imageInfo.rotationDegrees
                    var bmp = image.toBitmap(); image.close()
                    if (rot != 0) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height,
                        Matrix().apply { postRotate(rot.toFloat()) }, true)
                    bmp = sharpen(bmp, sharp * 0.1f)
                    val cv = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, "NITIDEZ_${stamp()}.jpg")
                        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/NitidezCam")
                    }
                    val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
                    contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.JPEG, 100, it) }
                    toast("Foto salva em Pictures/NitidezCam")
                } catch (e: Exception) { toast("Erro: ${e.message}") }
            }
            override fun onError(e: ImageCaptureException) { toast("Erro: ${e.message}") }
        })
    }

    // Máscara de nitidez (convolução 3x3)
    private fun sharpen(src: Bitmap, a: Float): Bitmap {
        if (a <= 0f) return src
        val rs = RenderScript.create(this)
        val inA = Allocation.createFromBitmap(rs, src)
        val outA = Allocation.createTyped(rs, inA.type)
        val s = ScriptIntrinsicConvolve3x3.create(rs, Element.U8_4(rs))
        s.setCoefficients(floatArrayOf(0f, -a, 0f, -a, 1 + 4 * a, -a, 0f, -a, 0f))
        s.setInput(inA); s.forEach(outA)
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        outA.copyTo(out); rs.destroy()
        return out
    }

    private fun toggleVideo() {
        val r = recording
        if (r != null) { r.stop(); return }
        val vc = videoCapture ?: return
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "NITIDEZ_${stamp()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/NitidezCam")
        }
        val opts = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv).build()
        var pr = vc.output.prepareRecording(this, opts)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            pr = pr.withAudioEnabled()
        shutter.text = "⏹"
        recording = pr.start(ContextCompat.getMainExecutor(this)) { ev ->
            if (ev is VideoRecordEvent.Finalize) {
                recording = null; shutter.text = "⏺"; toast("Vídeo salvo em Movies/NitidezCam")
            }
        }
    }

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    private fun toast(m: String) = runOnUiThread { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }
}
